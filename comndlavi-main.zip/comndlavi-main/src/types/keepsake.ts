export interface PhotoSlot {
  id: 'pic-1' | 'pic-2';
  src: string;
  label: string;
  title: string;
  caption: string;
  alt: string;
}

export interface CoupleKeepsakeData {
  titleLine1: string;
  titleLine2: string;
  photos: [PhotoSlot, PhotoSlot];
}
